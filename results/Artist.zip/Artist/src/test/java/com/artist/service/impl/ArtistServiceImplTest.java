package com.artist.service.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Sort;

import com.artist.dto.ArtistRequest;
import com.artist.model.Artist;
import com.artist.repository.ArtistRepository;

@ExtendWith(MockitoExtension.class)
class ArtistServiceImplTest {

    @Mock
    private ArtistRepository artistRepository;

    @InjectMocks
    private ArtistServiceImpl artistService;

    @Test
    void createArtist_savesAndReturnsArtist() {
        // given
        ArtistRequest request = new ArtistRequest("John", "Doe");
        Artist savedArtist = new Artist();
        savedArtist.setId(1L);
        savedArtist.setFirstName(request.firstName());
        savedArtist.setLastName(request.lastName());

        when(artistRepository.save(any(Artist.class))).thenReturn(savedArtist);

        // when
        Artist result = artistService.createArtist(request);

        // then
        assertNotNull(result);
        assertEquals(savedArtist.getId(), result.getId());
        assertEquals("John", result.getFirstName());
        assertEquals("Doe", result.getLastName());

        ArgumentCaptor<Artist> captor = ArgumentCaptor.forClass(Artist.class);
        verify(artistRepository).save(captor.capture());
        Artist captured = captor.getValue();
        assertEquals("John", captured.getFirstName());
        assertEquals("Doe", captured.getLastName());
    }

    @Test
    void getArtists_returnsAllArtistsSortedByIdAsc() {
        // given
        Artist a1 = new Artist();
        a1.setId(1L);
        Artist a2 = new Artist();
        a2.setId(2L);
        List<Artist> mockList = List.of(a1, a2);

        when(artistRepository.findAll(any(Sort.class))).thenReturn(mockList);

        // when
        List<Artist> result = artistService.getArtists();

        // then
        assertEquals(mockList, result);

        Sort expectedSort = Sort.by(Sort.Direction.ASC, "id");
        verify(artistRepository).findAll(eq(expectedSort));
    }

    @Test
    void getArtistByID_returnsArtistWhenFound() {
        // given
        Long id = 10L;
        Artist artist = new Artist();
        artist.setId(id);
        artist.setFirstName("Jane");
        artist.setLastName("Smith");

        when(artistRepository.findById(eq(id))).thenReturn(Optional.of(artist));

        // when
        Artist result = artistService.getArtistByID(id);

        // then
        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals("Jane", result.getFirstName());
        assertEquals("Smith", result.getLastName());

        verify(artistRepository).findById(eq(id));
    }

    @Test
    void getArtistByID_returnsNullWhenNotFound() {
        // given
        Long id = 20L;
        when(artistRepository.findById(eq(id))).thenReturn(Optional.empty());

        // when
        Artist result = artistService.getArtistByID(id);

        // then
        assertNull(result);
        verify(artistRepository).findById(eq(id));
    }

    @Test
    void deleteArtist_callsRepositoryDeleteById() {
        // given
        Long id = 5L;

        // when
        artistService.deleteArtist(id);

        // then
        verify(artistRepository).deleteById(eq(id));
    }
}
