package com.artist.repository;

import com.artist.model.Artist;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class ArtistRepositoryTest {

    @Autowired
    private ArtistRepository artistRepository;

    @Test
    void saveAndFindById() {
        // arrange
        Artist artist = new Artist();
        artist.setFirstName("John");
        artist.setLastName("Doe");

        // act
        Artist saved = artistRepository.save(artist);
        Optional<Artist> retrieved = artistRepository.findById(saved.getId());

        // assert
        assertTrue(retrieved.isPresent(), "Artist should be present in the repository");
        assertEquals(saved.getId(), retrieved.get().getId());
        assertEquals("John", retrieved.get().getFirstName());
        assertEquals("Doe", retrieved.get().getLastName());
    }

    @Test
    void findAllReturnsSavedArtists() {
        // arrange
        Artist a1 = new Artist();
        a1.setFirstName("Alice");
        a1.setLastName("Smith");

        Artist a2 = new Artist();
        a2.setFirstName("Bob");
        a2.setLastName("Johnson");

        artistRepository.save(a1);
        artistRepository.save(a2);

        // act
        List<Artist> artists = artistRepository.findAll();

        // assert
        assertNotNull(artists);
        assertTrue(artists.size() >= 2, "At least two artists should be returned");

        boolean foundAlice = artists.stream()
                .anyMatch(a -> "Alice".equals(a.getFirstName()) && "Smith".equals(a.getLastName()));
        boolean foundBob = artists.stream()
                .anyMatch(a -> "Bob".equals(a.getFirstName()) && "Johnson".equals(a.getLastName()));

        assertTrue(foundAlice, "Saved artist Alice should be present");
        assertTrue(foundBob, "Saved artist Bob should be present");
    }
}
