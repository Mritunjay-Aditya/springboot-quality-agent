package com.artist.controller;

import com.artist.dto.ArtistRequest;
import com.artist.model.Artist;
import com.artist.service.ArtistService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ArtistController.class)
class ArtistControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ArtistService artistService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testCreateArtist() throws Exception {
        ArtistRequest request = new ArtistRequest("John", "Doe");

        Artist saved = new Artist();
        saved.setId(1L);
        saved.setFirstName("John");
        saved.setLastName("Doe");

        when(artistService.createArtist(ArgumentMatchers.any(ArtistRequest.class)))
                .thenReturn(saved);

        mockMvc.perform(post("/v1/artists")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.firstName").value("John"))
                .andExpect(jsonPath("$.lastName").value("Doe"));
    }

    @Test
    void testGetArtistById_Found() throws Exception {
        Artist artist = new Artist();
        artist.setId(2L);
        artist.setFirstName("Jane");
        artist.setLastName("Smith");

        when(artistService.getArtistByID(2L)).thenReturn(artist);

        mockMvc.perform(get("/v1/artists/2"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(2))
                .andExpect(jsonPath("$.firstName").value("Jane"))
                .andExpect(jsonPath("$.lastName").value("Smith"));
    }

    @Test
    void testGetArtistById_NotFound() throws Exception {
        when(artistService.getArtistByID(99L)).thenReturn(null);

        mockMvc.perform(get("/v1/artists/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAllArtists() throws Exception {
        Artist a1 = new Artist();
        a1.setId(1L);
        a1.setFirstName("John");
        a1.setLastName("Doe");

        Artist a2 = new Artist();
        a2.setId(2L);
        a2.setFirstName("Jane");
        a2.setLastName("Smith");

        List<Artist> artists = Arrays.asList(a1, a2);
        when(artistService.getArtists()).thenReturn(artists);

        mockMvc.perform(get("/v1/artists"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].firstName").value("John"))
                .andExpect(jsonPath("$[0].lastName").value("Doe"))
                .andExpect(jsonPath("$[1].id").value(2))
                .andExpect(jsonPath("$[1].firstName").value("Jane"))
                .andExpect(jsonPath("$[1].lastName").value("Smith"));
    }

    @Test
    void testDeleteArtist() throws Exception {
        doNothing().when(artistService).deleteArtist(3L);

        mockMvc.perform(delete("/v1/artists/3"))
                .andExpect(status().isNoContent());
    }
}
