package com.artist.controller;

import com.artist.dto.ArtistRequest;
import com.artist.model.Artist;
import com.artist.service.ArtistService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("v1/artists")
public class ArtistController {
	@Autowired
    ArtistService artistService;

    @PostMapping()
    public ResponseEntity<Artist> createPlayList(@RequestBody ArtistRequest artistRequest){
    	Artist artist = artistService.createArtist(artistRequest);
        return ResponseEntity.status(201).body(artist);
    }

    @GetMapping("/{artistId}")
    public ResponseEntity<Artist> getArtistById(@PathVariable Long artistId){
    	Artist artist = artistService.getArtistByID(artistId);
    	if(artist == null) {
    		return ResponseEntity.status(404).build();
    	}
        return ResponseEntity.status(200).body(artist);
    }

    @GetMapping
    public ResponseEntity<List<Artist>> getAllArtists(){
    	List<Artist> artist = artistService.getArtists();
        return ResponseEntity.status(200).body(artist);
    }

    @DeleteMapping("/{artistId}")
    public ResponseEntity<Void> deleteArtist(@PathVariable Long artistId){
    	artistService.deleteArtist(artistId);
        return ResponseEntity.status(204).build();
    }
}
