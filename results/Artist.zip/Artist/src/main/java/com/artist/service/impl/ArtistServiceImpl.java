package com.artist.service.impl;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.artist.dto.ArtistRequest;
import com.artist.model.Artist;
import com.artist.repository.ArtistRepository;
import com.artist.service.ArtistService;

@Service
public class ArtistServiceImpl implements ArtistService {
    private final ArtistRepository artistRepository;

    public ArtistServiceImpl(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    @Override
    public Artist createArtist(ArtistRequest artistRequest){
    	Artist artist = new Artist();
    	artist.setFirstName(artistRequest.firstName());
    	artist.setLastName(artistRequest.lastName());
    	return artistRepository.save(artist);
    }

    @Override
    public List<Artist> getArtists() {
    	List<Artist> artist = artistRepository.findAll(Sort.by(Sort.Direction.ASC,"id"));
        return artist;
    }

    @Override
    public Artist getArtistByID(Long id) {
    	Artist artist = artistRepository.findById(id).orElse(null);
        return artist;
    }

    @Override
    public void deleteArtist(Long id) {
    	artistRepository.deleteById(id);
    }
}
